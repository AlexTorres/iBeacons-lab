//
//  GLBBeaconsPlugin.h
//  Beacon Triangulator
//
//  Created by John A Torres B on 29/03/14.
//  Copyright (c) 2014 Globant. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GLBBeaconsPlugin : NSObject



@end
